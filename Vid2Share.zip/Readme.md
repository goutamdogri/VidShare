# Video sharing platform like Youtube

[Model link](https://app.eraser.io/workspace/rq1bqbYgYP1kZ6uJiVRU?origin=share)

Practice project Made with instructor - Youtuber Hitesh Chowdhary
